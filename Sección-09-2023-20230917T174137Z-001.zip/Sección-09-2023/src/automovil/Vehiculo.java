/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automovil;

/**
 *
 * @author SENA
 */
public abstract class Vehiculo implements IVehiculo{
    private String marca;
    private String modelo;


    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
     
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    @Override
    public void acelerar() {
        System.out.println("motocicleta acelera");
    }

    @Override
    public void frenar() {
        System.out.println("motocicleta esta frenando");
    }
    

    @Override
    public void encender() {
        System.out.println("motocicleta esta prendiendo");
    }

    @Override
    public void apagar() {
        System.out.println("motocicleta esta apagandose");
    }

    @Override
    public void pitar() {
        System.out.println("motocicleta esta pitando");
    }
}




 