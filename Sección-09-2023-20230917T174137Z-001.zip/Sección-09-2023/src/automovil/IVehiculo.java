/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package automovil;

/**
 *
 * @author SENA
 */
public interface IVehiculo {
    void acelerar();
    void frenar();
    void encender();
    void apagar();
    void pitar();
}
