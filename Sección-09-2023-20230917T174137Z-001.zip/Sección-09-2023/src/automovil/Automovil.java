/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package automovil;

/**
 *
 * @author SENA
 */
public class Automovil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        Motocicleta motocicleta = new Motocicleta();
        motocicleta.setCilindrada(150);
        motocicleta.setMarca("kawazaki");
        motocicleta.setModelo("4*4");
        motocicleta.acelerar();
        motocicleta.apagar();
        motocicleta.encender();
        motocicleta.frenar();
        motocicleta.pitar();

        // Mostrar información de los vehículos

        System.out.println("\nInformación de la motocicleta:");
        mostrarInformacionVehiculo(motocicleta);

        // Calcular y mostrar el costo de mantenimiento de los vehículos
      
        double costoMantenimientoMotocicleta = calcularCostoMantenimiento(motocicleta);
        System.out.println("Costo de mantenimiento de la motocicleta: $" + costoMantenimientoMotocicleta);
    }

    // Método para mostrar información de un vehículo
    public static void mostrarInformacionVehiculo(Vehiculo Vehiculo) {
        System.out.println("Marca: " + Vehiculo.getMarca());
        System.out.println("Modelo: " + Vehiculo.getModelo());
        
    }

    // Método para calcular el costo de mantenimiento de un vehículo
    public static double calcularCostoMantenimiento(Vehiculo vehiculo) {
        // Aquí puedes implementar la lógica de cálculo del costo de mantenimiento
        // Supongamos que es un cálculo simple basado en el valor del vehículo
        double valorVehiculo = 20000; // Valor de referencia
        double porcentajeMantenimiento = 0.05; // 5% del valor del vehículo

        return valorVehiculo * porcentajeMantenimiento;
}
}
